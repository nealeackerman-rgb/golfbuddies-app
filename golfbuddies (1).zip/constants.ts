

import { User, Course, Round, GameFormat, Competition } from './types';

export const MOCK_USERS: User[] = [
  { id: 1, firstName: 'Jack', lastName: 'Nicklaus', email: 'jack@example.com', phone: '555-0101', profilePictureUrl: 'https://picsum.photos/id/1015/200/200', friendIds: [2, 3], password: 'password123', handicap: 3 },
  { id: 2, firstName: 'Tiger', lastName: 'Woods', email: 'tiger@example.com', phone: '555-0102', profilePictureUrl: 'https://picsum.photos/id/1025/200/200', friendIds: [1], password: 'password123', handicap: -5 },
  { id: 3, firstName: 'Annika', lastName: 'Sorenstam', email: 'annika@example.com', phone: '555-0103', profilePictureUrl: 'https://picsum.photos/id/1027/200/200', friendIds: [1, 4], password: 'password123', handicap: -6 },
  { id: 4, firstName: 'Rory', lastName: 'McIlroy', email: 'rory@example.com', phone: '555-0104', profilePictureUrl: 'https://picsum.photos/id/1028/200/200', friendIds: [3], password: 'password123', handicap: -4 },
];

const shuffle = (array: number[]) => [...array].sort(() => Math.random() - 0.5);
const baseIndices = Array.from({ length: 18 }, (_, i) => i + 1);

export const MOCK_COURSES: Course[] = [
  { id: 1, name: 'Pebble Beach Golf Links', location: 'Pebble Beach, CA', pars: [4, 4, 4, 3, 4, 5, 3, 4, 4, 4, 4, 3, 4, 5, 4, 4, 3, 5], handicapIndices: [9, 13, 1, 17, 3, 11, 15, 5, 7, 2, 12, 16, 6, 18, 4, 8, 14, 10], rating: 75.5, slope: 145 },
  { id: 2, name: 'Augusta National Golf Club', location: 'Augusta, GA', pars: [4, 5, 4, 3, 4, 4, 4, 5, 4, 4, 4, 3, 5, 4, 5, 3, 4, 4], handicapIndices: shuffle(baseIndices), rating: 76.2, slope: 148 },
  { id: 3, name: 'St. Andrews (Old Course)', location: 'St. Andrews, Scotland', pars: [4, 4, 4, 4, 5, 4, 4, 3, 4, 4, 3, 4, 4, 5, 4, 4, 4, 4], handicapIndices: shuffle(baseIndices), rating: 73.1, slope: 132 },
  { id: 4, name: 'Pinehurst No. 2', location: 'Pinehurst, NC', pars: [4, 4, 5, 4, 5, 3, 4, 4, 3, 5, 4, 4, 4, 4, 3, 4, 3, 4], handicapIndices: shuffle(baseIndices), rating: 76.5, slope: 147 },
  { id: 5, name: 'TPC Sawgrass (Stadium Course)', location: 'Ponte Vedra Beach, FL', pars: [4, 5, 3, 4, 4, 4, 4, 3, 5, 4, 5, 4, 3, 4, 4, 5, 3, 4], handicapIndices: shuffle(baseIndices), rating: 76.4, slope: 155 },
  { id: 6, name: 'Cypress Point Club', location: 'Pebble Beach, CA', pars: [4, 4, 4, 4, 3, 5, 4, 4, 4, 4, 4, 3, 4, 5, 3, 3, 4, 4], handicapIndices: shuffle(baseIndices), rating: 74.5, slope: 142 },
  { id: 7, name: 'Shinnecock Hills Golf Club', location: 'Southampton, NY', pars: [4, 3, 4, 4, 5, 4, 3, 4, 4, 4, 3, 4, 4, 5, 4, 4, 3, 4], handicapIndices: shuffle(baseIndices), rating: 74.4, slope: 140 },
  { id: 8, name: 'Oakmont Country Club', location: 'Oakmont, PA', pars: [4, 4, 4, 5, 4, 3, 4, 4, 4, 4, 4, 5, 3, 4, 4, 3, 4, 4], handicapIndices: shuffle(baseIndices), rating: 77.5, slope: 148 },
  { id: 9, name: 'Merion Golf Club (East Course)', location: 'Ardmore, PA', pars: [4, 5, 3, 5, 4, 4, 4, 4, 3, 4, 5, 4, 3, 4, 4, 4, 3, 4], handicapIndices: shuffle(baseIndices), rating: 73.0, slope: 145 },
  { id: 10, name: 'Winged Foot Golf Club (West)', location: 'Mamaroneck, NY', pars: [4, 4, 3, 4, 4, 4, 3, 4, 4, 5, 4, 4, 3, 4, 4, 4, 3, 4], handicapIndices: shuffle(baseIndices), rating: 76.1, slope: 140 },
  { id: 11, name: 'Torrey Pines (South Course)', location: 'La Jolla, CA', pars: [4, 4, 3, 4, 4, 5, 4, 3, 4, 4, 4, 3, 5, 4, 4, 5, 4, 5], handicapIndices: shuffle(baseIndices), rating: 78.1, slope: 148 },
  { id: 12, name: 'Bethpage State Park (Black)', location: 'Farmingdale, NY', pars: [4, 4, 3, 5, 4, 4, 5, 3, 4, 4, 4, 4, 5, 4, 4, 3, 4, 4], handicapIndices: shuffle(baseIndices), rating: 77.5, slope: 155 },
  { id: 13, name: 'Royal Melbourne Golf Club (West)', location: 'Black Rock, Australia', pars: [4, 4, 3, 5, 3, 4, 4, 4, 4, 4, 5, 3, 4, 4, 3, 4, 4, 4], handicapIndices: shuffle(baseIndices), rating: 74.0, slope: 139 },
  { id: 14, name: 'Muirfield Village Golf Club', location: 'Dublin, OH', pars: [4, 4, 4, 3, 5, 4, 5, 3, 4, 4, 5, 3, 4, 4, 5, 4, 3, 4], handicapIndices: shuffle(baseIndices), rating: 75.8, slope: 153 },
  { id: 15, name: 'Bandon Dunes Golf Resort (Bandon Dunes)', location: 'Bandon, OR', pars: [4, 3, 5, 4, 4, 3, 4, 4, 5, 4, 4, 3, 5, 4, 3, 4, 4, 5], handicapIndices: shuffle(baseIndices), rating: 74.1, slope: 143 },
  { id: 16, name: 'Kiawah Island Golf Resort (Ocean Course)', location: 'Kiawah Island, SC', pars: [4, 5, 4, 4, 3, 4, 5, 3, 4, 4, 5, 4, 4, 3, 4, 5, 3, 4], handicapIndices: shuffle(baseIndices), rating: 77.3, slope: 155 },
  { id: 17, name: 'Riviera Country Club', location: 'Pacific Palisades, CA', pars: [5, 4, 4, 3, 4, 3, 4, 4, 4, 4, 5, 4, 4, 3, 4, 3, 5, 4], handicapIndices: shuffle(baseIndices), rating: 75.0, slope: 140 },
  { id: 18, name: 'Whistling Straits (Straits Course)', location: 'Sheboygan, WI', pars: [4, 5, 3, 4, 5, 4, 3, 4, 4, 4, 5, 3, 4, 4, 4, 5, 3, 5], handicapIndices: shuffle(baseIndices), rating: 77.2, slope: 152 },
  { id: 19, name: 'Olympic Club (Lake Course)', location: 'San Francisco, CA', pars: [5, 4, 4, 4, 4, 4, 4, 3, 4, 4, 4, 4, 3, 4, 4, 5, 3, 4], handicapIndices: shuffle(baseIndices), rating: 74.8, slope: 142 },
  { id: 20, name: 'Valhalla Golf Club', location: 'Louisville, KY', pars: [4, 4, 3, 4, 4, 4, 5, 3, 4, 5, 4, 3, 5, 4, 4, 4, 3, 5], handicapIndices: shuffle(baseIndices), rating: 76.4, slope: 153 },
];

export const MOCK_COMPETITIONS: Competition[] = [
    {
        id: 'comp1',
        name: 'The GolfBuddies Annual',
        creatorId: 1,
        courses: [{ id: 1, name: MOCK_COURSES[0].name }],
        participantIds: [1, 2, 3, 4],
        gameFormat: GameFormat.SCRAMBLE,
        status: 'Active',
        teams: [
            { id: 't1_teamA', name: 'Aces', playerIds: [1, 2] },
            { id: 't1_teamB', name: 'Eagles', playerIds: [3, 4] }
        ],
        teamSize: 2,
        feed: [
            {
                id: 'feed1',
                userId: 3,
                userName: 'Annika Sorenstam',
                userProfilePictureUrl: MOCK_USERS[2].profilePictureUrl,
                timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
                type: 'comment',
                text: 'Team Eagles is coming for the trophy! 🦅',
                likes: 5
            }
        ],
    },
    {
        id: 'comp2',
        name: 'California Tour',
        creatorId: 2,
        courses: [
            { id: 1, name: MOCK_COURSES[0].name },
            { id: 6, name: MOCK_COURSES[5].name },
            { id: 11, name: MOCK_COURSES[10].name },
        ],
        participantIds: [1, 2, 3, 4],
        gameFormat: GameFormat.STROKE_PLAY,
        status: 'Active',
        feed: [],
    }
];

const generateScores = (pars: number[], scoreModifier: number) => {
    return pars.map((par, index) => ({
        hole: index + 1,
        par,
        strokes: par + Math.floor(Math.random() * 3) - 1 + scoreModifier,
    }));
};

export const MOCK_ROUNDS: Round[] = [
    {
        id: 'round1',
        courseId: 1,
        courseName: 'Pebble Beach Golf Links',
        date: '2024-07-20',
        players: [MOCK_USERS[0], MOCK_USERS[1]],
        scores: {
            '1': generateScores(MOCK_COURSES[0].pars, 0),
            '2': generateScores(MOCK_COURSES[0].pars, 1),
        },
        aiSummary: "Jack Nicklaus and Tiger Woods had a legendary duel at Pebble Beach. Jack's steady play gave him the edge, finishing with a stellar 72. Tiger fought hard but a couple of tough breaks on the back nine left him with a respectable 73.",
        likes: 128,
        comments: [
            { userId: 3, text: "Incredible round, Jack!", timestamp: new Date().toISOString() },
            { userId: 4, text: "Wish I was there!", timestamp: new Date().toISOString() },
        ],
        gameFormat: GameFormat.STROKE_PLAY,
        competitionId: 'comp1',
    },
    {
        id: 'round2',
        courseId: 2,
        courseName: 'Augusta National Golf Club',
        date: '2024-07-18',
        players: [MOCK_USERS[2], MOCK_USERS[3]],
        scores: {
            '3': generateScores(MOCK_COURSES[1].pars, -1),
            '4': generateScores(MOCK_COURSES[1].pars, 0),
        },
        likes: 95,
        comments: [
            { userId: 1, text: "Amazing playing Annika!", timestamp: new Date().toISOString() },
        ],
        gameFormat: GameFormat.STROKE_PLAY,
        competitionId: 'comp1',
    }
];